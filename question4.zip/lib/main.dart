import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  sampleFunction() {
    print('water started flowing ');
  }

  sampleFunction1() {
    print('Water stoped flowing ');
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
            body: Center(
                child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        new RaisedButton(
          child: Text(" Tap here  to Flow water "),
          onPressed: sampleFunction,
          color: Colors.red,
          textColor: Colors.white,
          splashColor: Colors.grey,
          padding: EdgeInsets.fromLTRB(10, 10, 10, 20),
          // padding: EdgeInsets.all(5),
          //content: new Text("water started flowing "),
        ),
        new Padding(
          padding: const EdgeInsets.only(top: 20.0),
        ),
        new RaisedButton(
          //padding: EdgeInsets.all(5),
          child: Text(" Tap here  Stop flowing  water "),
          onPressed: sampleFunction1,
          color: Colors.red,
          textColor: Colors.white,
          splashColor: Colors.grey,
          padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
          //content: new Text("Water stoped flowing"),
        )
      ],
    ))));
  }
}
